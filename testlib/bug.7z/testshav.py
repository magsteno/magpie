#test shavian dictionary

from importlib import reload
import testlib
reload(testlib)

LONGEST_KEY = 6

def lookup(chords):
    assert len(chords) <= LONGEST_KEY, '%d/%d' % (len(chords), LONGEST_KEY)

    outline = []
    numbers = ['𐑪', '𐑕', '𐑑', '𐑐', '𐑣', '𐑨', '𐑓', '𐑐', '𐑤', '𐑑']
    for stroke in chords:
        outline = [''.join(outline), '']
        for key in stroke:
            if key.isnumeric():
                outline[1] = '#'
                outline.append(numbers[int(key)])
            else:
                outline.append('#𐑕𐑑𐑒𐑐𐑢𐑣𐑮𐑨𐑪*𐑧𐑳𐑓𐑚𐑤𐑜𐑛𐑟'['#STKPWHRAO*EUFBLGDZ'.index(key)])
        outline.append('/')

    outline = tuple(''.join(outline[:-1]).split('/'))

    return testlib.steno_to_shav(outline)[0]
